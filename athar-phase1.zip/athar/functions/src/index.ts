import { initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import { getStorage } from 'firebase-admin/storage';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import * as logger from 'firebase-functions/logger';

initializeApp();

const REGION = 'europe-west1';
/** أقصى عمر لآخر تسجيل دخول مسموح به لحذف الحساب (إعادة مصادقة حديثة). */
const RECENT_LOGIN_SECONDS = 5 * 60;

/**
 * يحذف كل ما يخص المستخدم. تُضاف مجموعات الميزات اللاحقة (منشورات، تفاعلات، حفظ...)
 * إلى هذه الدالة في مراحلها، بحيث يبقى الحذف في مكان واحد موثوق.
 */
export async function deleteUserData(uid: string): Promise<void> {
  const db = getFirestore();

  const userRef = db.doc(`users/${uid}`);
  const userSnap = await userRef.get();
  const username = userSnap.exists ? (userSnap.data()?.username as string | undefined) : undefined;

  // ملفات التخزين (الصور الشخصية وغيرها لاحقًا)
  const bucket = getStorage().bucket();
  await bucket.deleteFiles({ prefix: `avatars/${uid}/` }).catch((e) => logger.warn('avatar cleanup failed', e));

  // وثيقة المستخدم وكل مجموعاتها الفرعية
  await db.recursiveDelete(userRef);

  // تحرير اسم المستخدم
  if (username) {
    await db.doc(`usernames/${username}`).delete().catch(() => undefined);
  }
}

export const deleteAccount = onCall({ region: REGION, enforceAppCheck: false }, async (request) => {
  const uid = request.auth?.uid;
  if (!uid) throw new HttpsError('unauthenticated', 'Sign in required.');

  const authTime = request.auth?.token.auth_time;
  const nowSec = Math.floor(Date.now() / 1000);
  if (typeof authTime !== 'number' || nowSec - authTime > RECENT_LOGIN_SECONDS) {
    throw new HttpsError('failed-precondition', 'Recent sign-in required.');
  }

  try {
    await deleteUserData(uid);
    await getAuth().deleteUser(uid);
  } catch (err) {
    logger.error('deleteAccount failed', { uid, err });
    throw new HttpsError('internal', 'Account deletion failed. Please try again.');
  }
  logger.info('account deleted', { uid });
  return { ok: true };
});
