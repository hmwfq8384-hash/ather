import { readFileSync } from 'node:fs';
import { afterAll, beforeAll, describe, it } from 'vitest';
import {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
  type RulesTestEnvironment,
} from '@firebase/rules-unit-testing';
import { ref, uploadBytes } from 'firebase/storage';

let env: RulesTestEnvironment;

beforeAll(async () => {
  env = await initializeTestEnvironment({
    projectId: 'athar-rules-test-storage',
    storage: { rules: readFileSync('storage.rules', 'utf8'), host: '127.0.0.1', port: 9199 },
  });
});

afterAll(async () => {
  await env.cleanup();
});

const bytes = (n: number) => new Uint8Array(n);

describe('avatars', () => {
  it('owner can upload a small jpeg', async () => {
    const s = env.authenticatedContext('u1').storage();
    await assertSucceeds(uploadBytes(ref(s, 'avatars/u1/a.jpg'), bytes(1000), { contentType: 'image/jpeg' }));
  });

  it("cannot upload into another user's folder", async () => {
    const s = env.authenticatedContext('u2').storage();
    await assertFails(uploadBytes(ref(s, 'avatars/u1/a.jpg'), bytes(1000), { contentType: 'image/jpeg' }));
  });

  it('rejects non-image types and oversized files', async () => {
    const s = env.authenticatedContext('u1').storage();
    await assertFails(uploadBytes(ref(s, 'avatars/u1/a.html'), bytes(100), { contentType: 'text/html' }));
    await assertFails(uploadBytes(ref(s, 'avatars/u1/svg.svg'), bytes(100), { contentType: 'image/svg+xml' }));
    await assertFails(uploadBytes(ref(s, 'avatars/u1/big.jpg'), bytes(3 * 1024 * 1024), { contentType: 'image/jpeg' }));
  });

  it('anonymous users cannot upload; other paths are closed', async () => {
    const anon = env.unauthenticatedContext().storage();
    await assertFails(uploadBytes(ref(anon, 'avatars/u1/a.jpg'), bytes(100), { contentType: 'image/jpeg' }));
    const s = env.authenticatedContext('u1').storage();
    await assertFails(uploadBytes(ref(s, 'misc/u1/a.jpg'), bytes(100), { contentType: 'image/jpeg' }));
  });

  it('suspended users cannot upload', async () => {
    const s = env.authenticatedContext('u1', { suspended: true }).storage();
    await assertFails(uploadBytes(ref(s, 'avatars/u1/a.jpg'), bytes(100), { contentType: 'image/jpeg' }));
  });
});
