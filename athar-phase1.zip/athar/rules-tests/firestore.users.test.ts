import { readFileSync } from 'node:fs';
import { afterAll, beforeAll, beforeEach, describe, it } from 'vitest';
import {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
  type RulesTestEnvironment,
} from '@firebase/rules-unit-testing';
import { doc, getDoc, serverTimestamp, setDoc, updateDoc, writeBatch } from 'firebase/firestore';

let env: RulesTestEnvironment;

beforeAll(async () => {
  env = await initializeTestEnvironment({
    projectId: 'athar-rules-test',
    firestore: { rules: readFileSync('firestore.rules', 'utf8'), host: '127.0.0.1', port: 8080 },
  });
});

afterAll(async () => {
  await env.cleanup();
});

beforeEach(async () => {
  await env.clearFirestore();
});

const privacy = {
  isPrivate: false,
  showHifz: true,
  showAchievements: true,
  showFollowLists: true,
  allowPartnerRequests: true,
};

function newUserDoc(uid: string, username: string) {
  return {
    uid,
    displayName: 'أحمد',
    username,
    photoURL: null,
    bio: '',
    joinedAt: serverTimestamp(),
    postsCount: 0,
    reactionsReceived: 0,
    followersCount: 0,
    followingCount: 0,
    privacy,
  };
}

async function register(uid: string, username: string) {
  const db = env.authenticatedContext(uid).firestore();
  const batch = writeBatch(db);
  batch.set(doc(db, 'usernames', username), { uid, createdAt: serverTimestamp() });
  batch.set(doc(db, 'users', uid), newUserDoc(uid, username));
  return batch.commit();
}

describe('registration', () => {
  it('creates profile and reserves the username atomically', async () => {
    await assertSucceeds(register('u1', 'ahmad'));
  });

  it('rejects a username that is already taken', async () => {
    await assertSucceeds(register('u1', 'ahmad'));
    await assertFails(register('u2', 'ahmad'));
  });

  it('rejects creating a profile without reserving the username', async () => {
    const db = env.authenticatedContext('u1').firestore();
    await assertFails(setDoc(doc(db, 'users', 'u1'), newUserDoc('u1', 'ahmad')));
  });

  it('rejects reserving a username for somebody else', async () => {
    const db = env.authenticatedContext('u1').firestore();
    const batch = writeBatch(db);
    batch.set(doc(db, 'usernames', 'mine'), { uid: 'u2', createdAt: serverTimestamp() });
    batch.set(doc(db, 'users', 'u1'), newUserDoc('u1', 'mine'));
    await assertFails(batch.commit());
  });

  it('rejects forged counters at creation', async () => {
    const db = env.authenticatedContext('u1').firestore();
    const batch = writeBatch(db);
    batch.set(doc(db, 'usernames', 'cheater'), { uid: 'u1', createdAt: serverTimestamp() });
    batch.set(doc(db, 'users', 'u1'), { ...newUserDoc('u1', 'cheater'), reactionsReceived: 999 });
    await assertFails(batch.commit());
  });

  it('rejects an invalid username format', async () => {
    await assertFails(register('u1', 'Bad Name'));
    await assertFails(register('u1', '1abc'));
  });

  it('rejects unauthenticated writes', async () => {
    const db = env.unauthenticatedContext().firestore();
    await assertFails(setDoc(doc(db, 'usernames', 'anon'), { uid: 'x', createdAt: serverTimestamp() }));
  });
});

describe('username lookup', () => {
  it('allows get by name but forbids listing', async () => {
    await register('u1', 'ahmad');
    const anon = env.unauthenticatedContext().firestore();
    await assertSucceeds(getDoc(doc(anon, 'usernames', 'ahmad')));
  });
});

describe('profile updates', () => {
  beforeEach(async () => {
    await register('u1', 'ahmad');
    await register('u2', 'sara');
  });

  it('owner can update name, bio and privacy', async () => {
    const db = env.authenticatedContext('u1').firestore();
    await assertSucceeds(updateDoc(doc(db, 'users', 'u1'), { displayName: 'أحمد علي', bio: 'نبذة', updatedAt: serverTimestamp() }));
    await assertSucceeds(updateDoc(doc(db, 'users', 'u1'), { privacy: { ...privacy, isPrivate: true } }));
  });

  it("another user cannot edit someone else's profile", async () => {
    const db = env.authenticatedContext('u2').firestore();
    await assertFails(updateDoc(doc(db, 'users', 'u1'), { bio: 'hacked' }));
  });

  it('cannot change counters, username, joinedAt or inject role fields', async () => {
    const db = env.authenticatedContext('u1').firestore();
    const ref = doc(db, 'users', 'u1');
    await assertFails(updateDoc(ref, { reactionsReceived: 500 }));
    await assertFails(updateDoc(ref, { postsCount: 1 }));
    await assertFails(updateDoc(ref, { username: 'other' }));
    await assertFails(updateDoc(ref, { joinedAt: serverTimestamp() }));
    await assertFails(updateDoc(ref, { isAdmin: true }));
    await assertFails(updateDoc(ref, { role: 'admin' }));
  });

  it('rejects over-long bio and malformed privacy', async () => {
    const db = env.authenticatedContext('u1').firestore();
    const ref = doc(db, 'users', 'u1');
    await assertFails(updateDoc(ref, { bio: 'x'.repeat(161) }));
    await assertFails(updateDoc(ref, { privacy: { ...privacy, extra: true } }));
    await assertFails(updateDoc(ref, { privacy: { ...privacy, isPrivate: 'yes' } }));
  });

  it('rejects non-https photo URLs', async () => {
    const db = env.authenticatedContext('u1').firestore();
    await assertFails(updateDoc(doc(db, 'users', 'u1'), { photoURL: 'javascript:alert(1)' }));
    await assertSucceeds(updateDoc(doc(db, 'users', 'u1'), { photoURL: 'https://example.com/a.jpg' }));
  });

  it('client can never delete a user document', async () => {
    const db = env.authenticatedContext('u1').firestore();
    const { deleteDoc } = await import('firebase/firestore');
    await assertFails(deleteDoc(doc(db, 'users', 'u1')));
  });

  it('suspended users (custom claim) cannot write', async () => {
    const db = env.authenticatedContext('u1', { suspended: true }).firestore();
    await assertFails(updateDoc(doc(db, 'users', 'u1'), { bio: 'x' }));
  });
});

describe('reads', () => {
  it('signed-in users can read profiles; anonymous cannot', async () => {
    await register('u1', 'ahmad');
    await assertSucceeds(getDoc(doc(env.authenticatedContext('u2').firestore(), 'users', 'u1')));
    await assertFails(getDoc(doc(env.unauthenticatedContext().firestore(), 'users', 'u1')));
  });

  it('unknown collections are closed', async () => {
    const db = env.authenticatedContext('u1').firestore();
    await assertFails(getDoc(doc(db, 'secrets', 'x')));
    await assertFails(setDoc(doc(db, 'secrets', 'x'), { a: 1 }));
  });
});
