const e = import.meta.env;

export const firebaseConfig = {
  apiKey: (e.VITE_FIREBASE_API_KEY as string | undefined) ?? '',
  authDomain: (e.VITE_FIREBASE_AUTH_DOMAIN as string | undefined) ?? '',
  projectId: (e.VITE_FIREBASE_PROJECT_ID as string | undefined) ?? '',
  storageBucket: (e.VITE_FIREBASE_STORAGE_BUCKET as string | undefined) ?? '',
  messagingSenderId: (e.VITE_FIREBASE_MESSAGING_SENDER_ID as string | undefined) ?? '',
  appId: (e.VITE_FIREBASE_APP_ID as string | undefined) ?? '',
};

export const isFirebaseConfigured = Boolean(
  firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId,
);

export const useEmulators = e.VITE_USE_EMULATORS === 'true';
export const recaptchaSiteKey = (e.VITE_RECAPTCHA_SITE_KEY as string | undefined) ?? '';
export const appCheckDebug = e.VITE_APPCHECK_DEBUG === 'true';
export const googleAuthEnabled = e.VITE_ENABLE_GOOGLE_AUTH === 'true';
export const appVersion = (e.VITE_APP_VERSION as string | undefined) ?? '0.1.0';
