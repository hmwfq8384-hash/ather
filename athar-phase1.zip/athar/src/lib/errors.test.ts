import { describe, expect, it } from 'vitest';
import { AppError, errorCode, toArabicError } from './errors';

describe('toArabicError', () => {
  it('maps known Firebase codes to Arabic messages', () => {
    expect(toArabicError({ code: 'auth/invalid-credential' })).toContain('غير صحيحة');
    expect(toArabicError({ code: 'auth/email-already-in-use' })).toContain('مسجّل');
    expect(toArabicError(new AppError('username-taken'))).toContain('محجوز');
  });

  it('falls back to a generic Arabic message for unknown errors', () => {
    expect(toArabicError(new Error('boom'))).toContain('غير متوقع');
    expect(toArabicError({ code: 'something/else' })).toContain('غير متوقع');
  });

  it('extracts codes safely', () => {
    expect(errorCode({ code: 'x' })).toBe('x');
    expect(errorCode(null)).toBe('unknown');
    expect(errorCode('str')).toBe('unknown');
  });
});
