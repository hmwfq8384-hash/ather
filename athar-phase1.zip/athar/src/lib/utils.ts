export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

const arFormatter = new Intl.NumberFormat('ar-EG');
export function formatNumber(n: number): string {
  return arFormatter.format(n);
}

export function formatDate(value: Date | null | undefined, opts?: Intl.DateTimeFormatOptions): string {
  if (!value) return '';
  return new Intl.DateTimeFormat('ar', opts ?? { year: 'numeric', month: 'long', day: 'numeric' }).format(value);
}
