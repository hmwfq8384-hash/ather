import { describe, expect, it } from 'vitest';
import { assertValidImage, MAX_SOURCE_BYTES } from './image';

const file = (type: string, size = 10) => new File([new Uint8Array(size)], 'x', { type });

describe('assertValidImage', () => {
  it('accepts jpeg/png/webp', () => {
    for (const t of ['image/jpeg', 'image/png', 'image/webp']) {
      expect(() => assertValidImage(file(t))).not.toThrow();
    }
  });

  it('rejects other file types', () => {
    for (const t of ['image/svg+xml', 'application/pdf', 'text/html', '']) {
      expect(() => assertValidImage(file(t))).toThrowError(/file-type/);
    }
  });

  it('rejects oversized files', () => {
    expect(() => assertValidImage(file('image/png', MAX_SOURCE_BYTES + 1))).toThrowError(/file-size/);
  });
});
