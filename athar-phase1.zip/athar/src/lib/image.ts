import { AppError } from './errors';

export const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
export const MAX_SOURCE_BYTES = 10 * 1024 * 1024;

/** يتحقق من نوع الصورة وحجمها قبل المعالجة. */
export function assertValidImage(file: File): void {
  if (!IMAGE_TYPES.includes(file.type)) throw new AppError('file-type');
  if (file.size > MAX_SOURCE_BYTES) throw new AppError('file-size');
}

/** يصغّر الصورة ويحوّلها إلى JPEG (يزيل بيانات EXIF أيضًا). */
export async function compressImage(file: File, maxSide = 512, quality = 0.85): Promise<Blob> {
  assertValidImage(file);
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new AppError('file-type');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new AppError('file-type'))), 'image/jpeg', quality);
  });
}
