import { getApp, getApps, initializeApp } from 'firebase/app';
import { initializeAppCheck, ReCaptchaV3Provider } from 'firebase/app-check';
import { connectAuthEmulator, getAuth } from 'firebase/auth';
import {
  connectFirestoreEmulator,
  getFirestore,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
} from 'firebase/firestore';
import { connectFunctionsEmulator, getFunctions } from 'firebase/functions';
import { connectStorageEmulator, getStorage } from 'firebase/storage';
import { appCheckDebug, firebaseConfig, isFirebaseConfigured, recaptchaSiteKey, useEmulators } from './env';

// قيم بديلة تمنع انهيار SDK عند غياب الإعداد؛ تُعرض شاشة الإعداد بدل التطبيق.
const config = isFirebaseConfigured
  ? firebaseConfig
  : { apiKey: 'missing', authDomain: 'missing', projectId: 'missing', appId: 'missing' };

const alreadyInitialized = getApps().length > 0;
export const app = alreadyInitialized ? getApp() : initializeApp(config);

if (!alreadyInitialized && isFirebaseConfigured && !useEmulators && recaptchaSiteKey) {
  if (appCheckDebug) {
    (self as unknown as { FIREBASE_APPCHECK_DEBUG_TOKEN?: boolean }).FIREBASE_APPCHECK_DEBUG_TOKEN = true;
  }
  initializeAppCheck(app, {
    provider: new ReCaptchaV3Provider(recaptchaSiteKey),
    isTokenAutoRefreshEnabled: true,
  });
}

export const auth = getAuth(app);

function createFirestore() {
  try {
    return initializeFirestore(app, {
      localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    });
  } catch {
    // أُنشئت النسخة مسبقًا (مثل إعادة التحميل الساخنة)
    return getFirestore(app);
  }
}

export const db = createFirestore();
export const storage = getStorage(app);
export const functions = getFunctions(app, 'europe-west1');

if (!alreadyInitialized && useEmulators) {
  connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
  connectFirestoreEmulator(db, '127.0.0.1', 8080);
  connectStorageEmulator(storage, '127.0.0.1', 9199);
  connectFunctionsEmulator(functions, '127.0.0.1', 5001);
}
