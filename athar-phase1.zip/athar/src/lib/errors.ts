import i18n from '@/i18n';

/** خطأ تطبيقي برمز يُترجم إلى رسالة عربية واضحة. */
export class AppError extends Error {
  readonly code: string;
  constructor(code: string, message?: string) {
    super(message ?? code);
    this.name = 'AppError';
    this.code = code;
  }
}

const KNOWN = new Set([
  'auth/invalid-credential',
  'auth/wrong-password',
  'auth/user-not-found',
  'auth/invalid-email',
  'auth/email-already-in-use',
  'auth/weak-password',
  'auth/too-many-requests',
  'auth/network-request-failed',
  'auth/popup-closed-by-user',
  'auth/popup-blocked',
  'auth/requires-recent-login',
  'auth/user-disabled',
  'auth/missing-password',
  'auth/account-exists-with-different-credential',
  'permission-denied',
  'unavailable',
  'unauthenticated',
  'not-found',
  'resource-exhausted',
  'functions/unauthenticated',
  'functions/failed-precondition',
  'username-taken',
  'username-invalid',
  'file-type',
  'file-size',
]);

export function errorCode(err: unknown): string {
  if (err && typeof err === 'object' && 'code' in err && typeof (err as { code: unknown }).code === 'string') {
    return (err as { code: string }).code;
  }
  return 'unknown';
}

export function toArabicError(err: unknown): string {
  const code = errorCode(err);
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return i18n.t('errors.offline');
  const key = KNOWN.has(code) ? code.replace('/', '_') : 'unknown';
  return i18n.t(`errors.${key}`);
}
