import { lazy, Suspense, type ReactElement } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { AppLayout } from '@/components/layout/AppLayout';
import { Toaster } from '@/components/ui/Toaster';
import { FullScreenLoader } from '@/components/ui/Skeleton';
import { useAuth } from '@/features/auth/AuthProvider';
import { isFirebaseConfigured } from '@/lib/env';
import { AboutPage, PrivacyPage, TermsPage } from '@/pages/StaticPages';

const WelcomePage = lazy(() => import('@/pages/WelcomePage'));
const LoginPage = lazy(() => import('@/pages/LoginPage'));
const SignupPage = lazy(() => import('@/pages/SignupPage'));
const ForgotPasswordPage = lazy(() => import('@/pages/ForgotPasswordPage'));
const CompleteProfilePage = lazy(() => import('@/pages/CompleteProfilePage'));
const HomePage = lazy(() => import('@/pages/HomePage'));
const ProfilePage = lazy(() => import('@/pages/ProfilePage'));
const SettingsPage = lazy(() => import('@/pages/SettingsPage'));
const NotFoundPage = lazy(() => import('@/pages/NotFoundPage'));
const SetupRequiredPage = lazy(() => import('@/pages/SetupRequiredPage'));
const MeRedirect = lazy(() => import('@/pages/ProfilePage').then((m) => ({ default: m.MeRedirect })));

/** صفحات الزائر فقط: المسجَّل يُحوَّل إلى التطبيق. */
function GuestOnly({ children }: { children: ReactElement }) {
  const { status } = useAuth();
  if (status === 'loading') return <FullScreenLoader />;
  if (status === 'ready') return <Navigate to="/" replace />;
  if (status === 'needsProfile') return <Navigate to="/complete-profile" replace />;
  return children;
}

/** صفحات المستخدم المكتمل ملفه. */
function RequireProfile({ children }: { children: ReactElement }) {
  const { status } = useAuth();
  if (status === 'loading') return <FullScreenLoader />;
  if (status === 'signedOut') return <Navigate to="/welcome" replace />;
  if (status === 'needsProfile') return <Navigate to="/complete-profile" replace />;
  return children;
}

function CompleteProfileGate() {
  const { status } = useAuth();
  if (status === 'loading') return <FullScreenLoader />;
  if (status === 'signedOut') return <Navigate to="/welcome" replace />;
  if (status === 'ready') return <Navigate to="/" replace />;
  return <CompleteProfilePage />;
}

export default function App() {
  if (!isFirebaseConfigured) {
    return (
      <Suspense fallback={<FullScreenLoader />}>
        <SetupRequiredPage />
      </Suspense>
    );
  }

  return (
    <>
      <Suspense fallback={<FullScreenLoader />}>
        <Routes>
          <Route path="/welcome" element={<GuestOnly><WelcomePage /></GuestOnly>} />
          <Route path="/login" element={<GuestOnly><LoginPage /></GuestOnly>} />
          <Route path="/signup" element={<GuestOnly><SignupPage /></GuestOnly>} />
          <Route path="/forgot-password" element={<GuestOnly><ForgotPasswordPage /></GuestOnly>} />
          <Route path="/complete-profile" element={<CompleteProfileGate />} />

          <Route path="/about" element={<AboutPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/terms" element={<TermsPage />} />

          <Route element={<RequireProfile><AppLayout /></RequireProfile>}>
            <Route index element={<HomePage />} />
            <Route path="me" element={<MeRedirect />} />
            <Route path="u/:username" element={<ProfilePage />} />
            <Route path="settings" element={<SettingsPage />} />
          </Route>

          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Suspense>
      <Toaster />
    </>
  );
}
