import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import ar from './ar.json';
import en from './en.json';

export type Lang = 'ar' | 'en';

/** يحوّل كائن الترجمة إلى مجموعة مفاتيح مسطحة للمقارنة. */
export function flattenKeys(obj: unknown, prefix = ''): string[] {
  if (obj === null || typeof obj !== 'object' || Array.isArray(obj)) return prefix ? [prefix] : [];
  return Object.entries(obj as Record<string, unknown>).flatMap(([k, v]) =>
    flattenKeys(v, prefix ? `${prefix}.${k}` : k),
  );
}

/** اللغة تُعدّ مكتملة فقط إذا غطّت كل مفاتيح العربية (اللغة المرجعية). */
export function isLanguageComplete(resource: unknown, reference: unknown = ar): boolean {
  const have = new Set(flattenKeys(resource));
  return flattenKeys(reference).every((k) => have.has(k));
}

export const availableLanguages: Lang[] = isLanguageComplete(en) ? ['ar', 'en'] : ['ar'];

export function applyDocumentLanguage(lang: Lang, doc: Document = document): void {
  doc.documentElement.lang = lang;
  doc.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
}

void i18n.use(initReactI18next).init({
  resources: { ar: { translation: ar }, en: { translation: en } },
  lng: 'ar',
  fallbackLng: 'ar',
  interpolation: { escapeValue: false },
});

export default i18n;
