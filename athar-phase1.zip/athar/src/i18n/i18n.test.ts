import { describe, expect, it } from 'vitest';
import ar from './ar.json';
import en from './en.json';
import { availableLanguages, flattenKeys, isLanguageComplete } from './index';

describe('i18n completeness', () => {
  it('Arabic is always complete against itself', () => {
    expect(isLanguageComplete(ar)).toBe(true);
  });

  it('exposes English only when every Arabic key is translated', () => {
    const complete = isLanguageComplete(en);
    expect(availableLanguages.includes('en')).toBe(complete);
  });

  it('detects a missing key', () => {
    expect(isLanguageComplete({ a: { b: 'x' } }, { a: { b: 'x', c: 'y' } })).toBe(false);
    expect(isLanguageComplete({ a: { b: 'x', c: 'y' } }, { a: { b: 'x' } })).toBe(true);
  });

  it('flattens nested keys', () => {
    expect(flattenKeys({ a: { b: 1, c: { d: 2 } }, e: 3 }).sort()).toEqual(['a.b', 'a.c.d', 'e']);
  });

  it('every validation/error message key used by code exists in Arabic', () => {
    const keys = new Set(flattenKeys(ar));
    for (const k of [
      'validation.required', 'validation.email', 'validation.passwordShort', 'validation.passwordWeak',
      'validation.passwordMismatch', 'validation.displayNameLength', 'validation.usernameFormat',
      'validation.usernameReserved', 'validation.bioLength', 'errors.unknown', 'errors.offline',
      'errors.username-taken', 'errors.permission-denied',
    ]) {
      expect(keys.has(k), k).toBe(true);
    }
  });
});
