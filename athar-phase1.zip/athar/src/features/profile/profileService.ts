import { doc, getDoc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { deleteObject, getDownloadURL, ref, uploadBytes } from 'firebase/storage';
import { updateProfile as updateAuthProfile } from 'firebase/auth';
import { auth, db, storage } from '@/lib/firebase';
import { compressImage } from '@/lib/image';
import { toProfile, type PrivacySettings, type UserProfile } from '@/features/auth/types';
import { normalizeUsername } from '@/features/auth/schemas';

export async function getProfileByUsername(rawUsername: string): Promise<UserProfile | null> {
  const username = normalizeUsername(rawUsername);
  const nameSnap = await getDoc(doc(db, 'usernames', username));
  if (!nameSnap.exists()) return null;
  const uid = (nameSnap.data() as { uid?: string }).uid;
  if (!uid) return null;
  const userSnap = await getDoc(doc(db, 'users', uid));
  return userSnap.exists() ? toProfile(uid, userSnap.data()) : null;
}

export async function updateProfileInfo(
  uid: string,
  data: { displayName: string; bio: string },
): Promise<void> {
  const displayName = data.displayName.trim();
  await updateDoc(doc(db, 'users', uid), {
    displayName,
    bio: data.bio.trim(),
    updatedAt: serverTimestamp(),
  });
  if (auth.currentUser) await updateAuthProfile(auth.currentUser, { displayName }).catch(() => undefined);
}

export async function updatePrivacy(uid: string, privacy: PrivacySettings): Promise<void> {
  await updateDoc(doc(db, 'users', uid), { privacy, updatedAt: serverTimestamp() });
}

function isOwnStorageUrl(url: string | null): url is string {
  return !!url && url.includes('firebasestorage.googleapis.com') && url.includes(encodeURIComponent('avatars/'));
}

async function removeOldAvatar(url: string | null): Promise<void> {
  if (!isOwnStorageUrl(url)) return;
  try {
    await deleteObject(ref(storage, url));
  } catch {
    // الملف القديم قد يكون محذوفًا مسبقًا؛ لا يمنع ذلك التحديث
  }
}

/** يضغط الصورة ويرفعها ثم يحدّث رابط الصورة الشخصية. */
export async function uploadAvatar(uid: string, file: File, previousUrl: string | null): Promise<string> {
  const blob = await compressImage(file, 512, 0.85);
  const fileRef = ref(storage, `avatars/${uid}/${Date.now()}.jpg`);
  await uploadBytes(fileRef, blob, { contentType: 'image/jpeg', cacheControl: 'public,max-age=31536000' });
  const url = await getDownloadURL(fileRef);
  await updateDoc(doc(db, 'users', uid), { photoURL: url, updatedAt: serverTimestamp() });
  if (auth.currentUser) await updateAuthProfile(auth.currentUser, { photoURL: url }).catch(() => undefined);
  await removeOldAvatar(previousUrl);
  return url;
}

export async function removeAvatar(uid: string, previousUrl: string | null): Promise<void> {
  await updateDoc(doc(db, 'users', uid), { photoURL: null, updatedAt: serverTimestamp() });
  if (auth.currentUser) await updateAuthProfile(auth.currentUser, { photoURL: null }).catch(() => undefined);
  await removeOldAvatar(previousUrl);
}
