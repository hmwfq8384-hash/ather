import { useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Camera, Trash2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Avatar } from '@/components/ui/Avatar';
import { Button } from '@/components/ui/Button';
import { Input, TextArea } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { editProfileSchema, msg, type EditProfileInput } from '@/features/auth/schemas';
import type { UserProfile } from '@/features/auth/types';
import { toArabicError } from '@/lib/errors';
import { toast } from '@/store/toastStore';
import { removeAvatar, updateProfileInfo, uploadAvatar } from './profileService';

interface Props {
  open: boolean;
  profile: UserProfile;
  onClose: () => void;
}

export function EditProfileModal({ open, profile, onClose }: Props) {
  const { t } = useTranslation();
  const fileRef = useRef<HTMLInputElement>(null);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [saving, setSaving] = useState(false);
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<EditProfileInput>({
    resolver: zodResolver(editProfileSchema),
    defaultValues: { displayName: profile.displayName, bio: profile.bio },
  });

  const busy = photoBusy || saving;

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    setPhotoBusy(true);
    try {
      await uploadAvatar(profile.uid, file, profile.photoURL);
      toast.success(t('profile.photoUpdated'));
    } catch (err) {
      toast.error(toArabicError(err));
    } finally {
      setPhotoBusy(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const onRemove = async () => {
    setPhotoBusy(true);
    try {
      await removeAvatar(profile.uid, profile.photoURL);
      toast.success(t('profile.photoUpdated'));
    } catch (err) {
      toast.error(toArabicError(err));
    } finally {
      setPhotoBusy(false);
    }
  };

  const onSubmit = handleSubmit(async (values) => {
    setSaving(true);
    try {
      await updateProfileInfo(profile.uid, { displayName: values.displayName, bio: values.bio });
      toast.success(t('common.saved'));
      onClose();
    } catch (err) {
      toast.error(toArabicError(err));
    } finally {
      setSaving(false);
    }
  });

  return (
    <Modal open={open} title={t('profile.editProfile')} onClose={onClose} locked={busy}>
      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        <div className="flex items-center gap-4">
          <Avatar src={profile.photoURL} name={profile.displayName} size={72} />
          <div className="flex flex-wrap gap-2">
            <input
              ref={fileRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="sr-only"
              id="avatar-input"
              onChange={(e) => void onFile(e.target.files?.[0])}
            />
            <Button size="sm" variant="outline" loading={photoBusy} onClick={() => fileRef.current?.click()}>
              <Camera className="h-4 w-4" aria-hidden />
              {t('profile.changePhoto')}
            </Button>
            {profile.photoURL && (
              <Button size="sm" variant="ghost" disabled={busy} onClick={() => void onRemove()}>
                <Trash2 className="h-4 w-4" aria-hidden />
                {t('profile.removePhoto')}
              </Button>
            )}
          </div>
        </div>
        <Input
          label={t('auth.displayName')}
          maxLength={40}
          error={msg(errors.displayName?.message)}
          {...register('displayName')}
        />
        <TextArea
          label={t('profile.bio')}
          optionalLabel={t('common.optional')}
          maxLength={160}
          placeholder={t('profile.bioPlaceholder')}
          hint={`${(watch('bio') ?? '').length}/160`}
          error={msg(errors.bio?.message)}
          {...register('bio')}
        />
        <div className="flex gap-3">
          <Button type="submit" className="flex-1" loading={saving} disabled={photoBusy}>
            {t('common.save')}
          </Button>
          <Button variant="outline" className="flex-1" onClick={onClose} disabled={busy}>
            {t('common.cancel')}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
