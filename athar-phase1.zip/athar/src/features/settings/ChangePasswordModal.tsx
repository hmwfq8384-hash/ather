import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useTranslation } from 'react-i18next';
import type { User } from 'firebase/auth';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { changePassword } from '@/features/auth/authService';
import { changePasswordSchema, msg, type ChangePasswordInput } from '@/features/auth/schemas';
import { toArabicError } from '@/lib/errors';
import { toast } from '@/store/toastStore';

interface Props {
  open: boolean;
  user: User;
  onClose: () => void;
}

export function ChangePasswordModal({ open, user, onClose }: Props) {
  const { t } = useTranslation();
  const [saving, setSaving] = useState(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ChangePasswordInput>({ resolver: zodResolver(changePasswordSchema) });

  const close = () => {
    reset();
    onClose();
  };

  const onSubmit = handleSubmit(async (v) => {
    setSaving(true);
    try {
      await changePassword(user, v.currentPassword, v.newPassword);
      toast.success(t('settings.passwordChanged'));
      close();
    } catch (err) {
      toast.error(toArabicError(err));
    } finally {
      setSaving(false);
    }
  });

  return (
    <Modal open={open} title={t('settings.changePassword')} onClose={close} locked={saving}>
      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        <Input
          label={t('settings.currentPassword')}
          type="password"
          dir="ltr"
          autoComplete="current-password"
          className="text-left"
          error={msg(errors.currentPassword?.message)}
          {...register('currentPassword')}
        />
        <Input
          label={t('settings.newPassword')}
          type="password"
          dir="ltr"
          autoComplete="new-password"
          className="text-left"
          hint={t('auth.passwordHint')}
          error={msg(errors.newPassword?.message)}
          {...register('newPassword')}
        />
        <div className="flex gap-3">
          <Button type="submit" className="flex-1" loading={saving}>
            {t('common.save')}
          </Button>
          <Button variant="outline" className="flex-1" onClick={close} disabled={saving}>
            {t('common.cancel')}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
