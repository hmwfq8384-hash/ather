import type { ReactNode } from 'react';
import { cn } from '@/lib/utils';

export function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="card overflow-hidden">
      <h2 className="border-b border-border px-4 py-3 text-sm font-bold text-accent">{title}</h2>
      <div className="divide-y divide-border">{children}</div>
    </section>
  );
}

export function Row({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn('flex items-center justify-between gap-3 px-4 py-3', className)}>{children}</div>;
}

interface SwitchProps {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  hint?: string;
  disabled?: boolean;
}

export function SwitchRow({ checked, onChange, label, hint, disabled }: SwitchProps) {
  return (
    <Row>
      <div className="min-w-0">
        <div className="font-medium">{label}</div>
        {hint && <div className="text-xs text-muted">{hint}</div>}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={cn(
          'relative h-7 w-12 shrink-0 rounded-full border border-border disabled:opacity-60',
          checked ? 'bg-primary' : 'bg-surface2',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all',
            checked ? 'end-0.5' : 'start-0.5',
          )}
        />
      </button>
    </Row>
  );
}

interface ChoiceProps<T extends string> {
  value: T;
  onChange: (v: T) => void;
  options: Array<{ value: T; label: string; disabled?: boolean }>;
  label: string;
}

export function ChoiceGroup<T extends string>({ value, onChange, options, label }: ChoiceProps<T>) {
  return (
    <div role="radiogroup" aria-label={label} className="grid gap-2 px-4 py-3 sm:grid-cols-2">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          disabled={o.disabled}
          onClick={() => onChange(o.value)}
          className={cn(
            'rounded-xl border px-3 py-2.5 text-sm font-medium disabled:opacity-50',
            value === o.value ? 'border-accent bg-surface2 text-accent' : 'border-border hover:bg-surface2',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
