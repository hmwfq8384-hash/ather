import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { User } from 'firebase/auth';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { Input } from '@/components/ui/Input';
import { deleteAccount, usesPassword } from '@/features/auth/authService';
import { toArabicError } from '@/lib/errors';
import { toast } from '@/store/toastStore';

interface Props {
  open: boolean;
  user: User;
  onClose: () => void;
}

export function DeleteAccountDialog({ open, user, onClose }: Props) {
  const { t } = useTranslation();
  const [password, setPassword] = useState('');
  const needsPassword = usesPassword(user);

  const close = () => {
    setPassword('');
    onClose();
  };

  const confirm = async () => {
    try {
      await deleteAccount(user, needsPassword ? password : undefined);
      toast.success(t('settings.deleted'));
    } catch (err) {
      toast.error(toArabicError(err));
    }
  };

  return (
    <ConfirmDialog
      open={open}
      danger
      title={t('settings.deleteConfirmTitle')}
      description={needsPassword ? t('settings.deleteConfirmBody') : t('settings.deleteConfirmGoogle')}
      confirmLabel={t('settings.deleteAction')}
      onConfirm={confirm}
      onClose={close}
    >
      {needsPassword && (
        <Input
          label={t('auth.password')}
          type="password"
          dir="ltr"
          autoComplete="current-password"
          className="text-left"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      )}
    </ConfirmDialog>
  );
}
