import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase';
import { isFirebaseConfigured } from '@/lib/env';
import { useAuthFlow } from './authFlowStore';
import { toProfile, type UserProfile } from './types';

export type AuthStatus = 'loading' | 'signedOut' | 'needsProfile' | 'ready';

interface AuthContextValue {
  status: AuthStatus;
  user: User | null;
  profile: UserProfile | null;
  /** يزداد عند تغيّر بيانات المستخدم محليًا (مثل تفعيل البريد) لإعادة العرض. */
  userVersion: number;
  bumpUser: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [authResolved, setAuthResolved] = useState(!isFirebaseConfigured);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [profileResolved, setProfileResolved] = useState(false);
  const [userVersion, setUserVersion] = useState(0);
  const flowBusy = useAuthFlow((s) => s.busy);

  useEffect(() => {
    if (!isFirebaseConfigured) return;
    return onAuthStateChanged(auth, (u) => {
      setUser(u);
      setAuthResolved(true);
      if (!u) {
        setProfile(null);
        setProfileResolved(false);
      }
    });
  }, []);

  const uid = user?.uid ?? null;
  useEffect(() => {
    if (!uid) return;
    setProfileResolved(false);
    // اشتراك واحد فقط لوثيقة المستخدم الحالي
    return onSnapshot(
      doc(db, 'users', uid),
      (snap) => {
        setProfile(snap.exists() ? toProfile(uid, snap.data()) : null);
        setProfileResolved(true);
      },
      () => {
        setProfile(null);
        setProfileResolved(true);
      },
    );
  }, [uid]);

  const status: AuthStatus = useMemo(() => {
    if (!authResolved) return 'loading';
    if (!user) return 'signedOut';
    if (!profileResolved) return 'loading';
    if (profile) return 'ready';
    return flowBusy ? 'loading' : 'needsProfile';
  }, [authResolved, user, profileResolved, profile, flowBusy]);

  const value = useMemo<AuthContextValue>(
    () => ({ status, user, profile, userVersion, bumpUser: () => setUserVersion((v) => v + 1) }),
    [status, user, profile, userVersion],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}

/** للصفحات المحمية: الملف الشخصي مضمون الوجود. */
export function useCurrentProfile(): { user: User; profile: UserProfile } {
  const { user, profile } = useAuth();
  if (!user || !profile) throw new Error('useCurrentProfile requires a signed-in user with a profile');
  return { user, profile };
}
