import { z } from 'zod';
import i18n from '@/i18n';

export const USERNAME_REGEX = /^[a-z][a-z0-9_]{2,19}$/;

const RESERVED = new Set([
  'admin', 'administrator', 'athar', 'support', 'help', 'moderator', 'mod', 'root', 'system',
  'official', 'staff', 'settings', 'login', 'signup', 'welcome', 'me', 'null', 'undefined',
  'api', 'about', 'privacy', 'terms', 'quran', 'allah', 'muhammad',
]);

export function isReservedUsername(u: string): boolean {
  return RESERVED.has(u.toLowerCase());
}

export function normalizeUsername(raw: string): string {
  return raw.trim().replace(/^@/, '').toLowerCase();
}

const t = (key: string) => i18n.t(key);

export const emailSchema = z.string().trim().min(1, { message: 'validation.required' }).email({ message: 'validation.email' });

export const passwordSchema = z
  .string()
  .min(8, { message: 'validation.passwordShort' })
  .refine((v) => /[A-Za-z؀-ۿ]/.test(v) && /\d/.test(v), { message: 'validation.passwordWeak' });

export const displayNameSchema = z
  .string()
  .trim()
  .min(2, { message: 'validation.displayNameLength' })
  .max(40, { message: 'validation.displayNameLength' });

export const usernameSchema = z
  .string()
  .transform(normalizeUsername)
  .refine((v) => USERNAME_REGEX.test(v), { message: 'validation.usernameFormat' })
  .refine((v) => !isReservedUsername(v), { message: 'validation.usernameReserved' });

export const bioSchema = z.string().trim().max(160, { message: 'validation.bioLength' });

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, { message: 'validation.required' }),
});

export const signupSchema = z
  .object({
    displayName: displayNameSchema,
    username: usernameSchema,
    email: emailSchema,
    password: passwordSchema,
    confirmPassword: z.string(),
  })
  .refine((v) => v.password === v.confirmPassword, {
    path: ['confirmPassword'],
    message: 'validation.passwordMismatch',
  });

export const resetSchema = z.object({ email: emailSchema });

export const completeProfileSchema = z.object({
  displayName: displayNameSchema,
  username: usernameSchema,
});

export const editProfileSchema = z.object({
  displayName: displayNameSchema,
  bio: bioSchema,
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, { message: 'validation.required' }),
  newPassword: passwordSchema,
});

export type LoginInput = z.input<typeof loginSchema>;
export type SignupInput = z.input<typeof signupSchema>;
export type CompleteProfileInput = z.input<typeof completeProfileSchema>;
export type EditProfileInput = z.input<typeof editProfileSchema>;
export type ChangePasswordInput = z.input<typeof changePasswordSchema>;

/** رسائل zod تحمل مفاتيح ترجمة؛ هذه الدالة تحوّلها إلى نص. */
export function msg(message: string | undefined): string | undefined {
  return message ? t(message) : undefined;
}
