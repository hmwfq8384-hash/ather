import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/Button';
import { googleAuthEnabled } from '@/lib/env';
import { toArabicError } from '@/lib/errors';
import { toast } from '@/store/toastStore';
import { loginWithGoogle } from './authService';

/** يظهر فقط عند تفعيل المزود عبر VITE_ENABLE_GOOGLE_AUTH. */
export function GoogleButton() {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  if (!googleAuthEnabled) return null;

  const run = async () => {
    setLoading(true);
    try {
      await loginWithGoogle();
    } catch (err) {
      toast.error(toArabicError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="my-4 flex items-center gap-3 text-xs text-muted" aria-hidden>
        <span className="h-px flex-1 bg-border" />
        {t('common.or')}
        <span className="h-px flex-1 bg-border" />
      </div>
      <Button variant="outline" block onClick={run} loading={loading}>
        {t('auth.continueWithGoogle')}
      </Button>
    </>
  );
}
