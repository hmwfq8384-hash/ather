import { useEffect, useState } from 'react';
import type { UseFormRegisterReturn } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Input } from '@/components/ui/Input';
import { USERNAME_REGEX, isReservedUsername, normalizeUsername } from './schemas';
import { isUsernameAvailable } from './authService';

interface Props {
  register: UseFormRegisterReturn;
  value: string;
  error?: string;
}

/** حقل اسم المستخدم مع تحقق مباشر من التوفر (بعد توقف الكتابة قليلًا). */
export function UsernameField({ register, value, error }: Props) {
  const { t } = useTranslation();
  const [state, setState] = useState<'idle' | 'checking' | 'available' | 'taken'>('idle');

  useEffect(() => {
    const u = normalizeUsername(value);
    if (!USERNAME_REGEX.test(u) || isReservedUsername(u)) {
      setState('idle');
      return;
    }
    setState('checking');
    let cancelled = false;
    const timer = setTimeout(() => {
      isUsernameAvailable(u)
        .then((ok) => !cancelled && setState(ok ? 'available' : 'taken'))
        .catch(() => !cancelled && setState('idle'));
    }, 400);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [value]);

  const status =
    state === 'checking'
      ? t('auth.usernameChecking')
      : state === 'available'
        ? t('auth.usernameAvailable')
        : state === 'taken'
          ? t('auth.usernameTaken')
          : null;

  return (
    <Input
      label={t('auth.username')}
      dir="ltr"
      autoComplete="username"
      autoCapitalize="none"
      autoCorrect="off"
      spellCheck={false}
      maxLength={20}
      className="text-left"
      error={error ?? (state === 'taken' ? t('auth.usernameTaken') : undefined)}
      hint={status ? <span aria-live="polite">{status}</span> : t('auth.usernameHint')}
      {...register}
    />
  );
}
