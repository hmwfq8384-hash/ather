import { create } from 'zustand';

/**
 * أثناء إنشاء الحساب يظهر مستخدم Auth قبل أن تُكتب وثيقة ملفه في Firestore.
 * هذا المؤشر يمنع التحويل المؤقت إلى «أكمل ملفك» أثناء العملية.
 */
interface AuthFlowState {
  busy: boolean;
  setBusy: (b: boolean) => void;
}

export const useAuthFlow = create<AuthFlowState>((set) => ({
  busy: false,
  setBusy: (busy) => set({ busy }),
}));
