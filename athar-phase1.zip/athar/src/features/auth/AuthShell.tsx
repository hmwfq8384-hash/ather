import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Logo } from '@/components/Logo';

interface Props {
  title: string;
  subtitle?: string;
  children: ReactNode;
  backTo?: string;
}

export function AuthShell({ title, subtitle, children, backTo = '/welcome' }: Props) {
  const { t } = useTranslation();
  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center px-4 py-8 pt-safe">
      <Link to={backTo} className="mb-4 inline-flex items-center gap-1 self-start text-sm text-muted hover:text-fg">
        <ArrowRight className="h-4 w-4" aria-hidden />
        {t('common.back')}
      </Link>
      <div className="card p-6">
        <div className="mb-5 flex flex-col items-center gap-2 text-center">
          <Logo size={56} />
          <h1 className="text-2xl font-bold">{title}</h1>
          {subtitle && <p className="text-sm leading-6 text-muted">{subtitle}</p>}
        </div>
        {children}
      </div>
    </main>
  );
}
