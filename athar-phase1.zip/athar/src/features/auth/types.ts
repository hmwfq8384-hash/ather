import type { Timestamp } from 'firebase/firestore';

export interface PrivacySettings {
  isPrivate: boolean;
  showHifz: boolean;
  showAchievements: boolean;
  showFollowLists: boolean;
  allowPartnerRequests: boolean;
}

export const DEFAULT_PRIVACY: PrivacySettings = {
  isPrivate: false,
  showHifz: true,
  showAchievements: true,
  showFollowLists: true,
  allowPartnerRequests: true,
};

export interface UserProfile {
  uid: string;
  displayName: string;
  username: string;
  photoURL: string | null;
  bio: string;
  joinedAt: Date | null;
  postsCount: number;
  reactionsReceived: number;
  followersCount: number;
  followingCount: number;
  privacy: PrivacySettings;
}

type Raw = Record<string, unknown>;

const num = (v: unknown): number => (typeof v === 'number' && Number.isFinite(v) ? v : 0);
const bool = (v: unknown, d: boolean): boolean => (typeof v === 'boolean' ? v : d);

export function toProfile(uid: string, data: Raw): UserProfile {
  const p = (data.privacy ?? {}) as Raw;
  const joined = data.joinedAt as Timestamp | null | undefined;
  return {
    uid,
    displayName: typeof data.displayName === 'string' ? data.displayName : '',
    username: typeof data.username === 'string' ? data.username : '',
    photoURL: typeof data.photoURL === 'string' ? data.photoURL : null,
    bio: typeof data.bio === 'string' ? data.bio : '',
    joinedAt: joined && typeof joined.toDate === 'function' ? joined.toDate() : null,
    postsCount: num(data.postsCount),
    reactionsReceived: num(data.reactionsReceived),
    followersCount: num(data.followersCount),
    followingCount: num(data.followingCount),
    privacy: {
      isPrivate: bool(p.isPrivate, DEFAULT_PRIVACY.isPrivate),
      showHifz: bool(p.showHifz, DEFAULT_PRIVACY.showHifz),
      showAchievements: bool(p.showAchievements, DEFAULT_PRIVACY.showAchievements),
      showFollowLists: bool(p.showFollowLists, DEFAULT_PRIVACY.showFollowLists),
      allowPartnerRequests: bool(p.allowPartnerRequests, DEFAULT_PRIVACY.allowPartnerRequests),
    },
  };
}
