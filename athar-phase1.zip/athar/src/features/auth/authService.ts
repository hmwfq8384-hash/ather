import {
  EmailAuthProvider,
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  reauthenticateWithCredential,
  reauthenticateWithPopup,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updatePassword,
  updateProfile,
  type User,
} from 'firebase/auth';
import { doc, getDoc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { auth, db, functions } from '@/lib/firebase';
import { AppError } from '@/lib/errors';
import { useAuthFlow } from './authFlowStore';
import { DEFAULT_PRIVACY } from './types';
import { USERNAME_REGEX, isReservedUsername, normalizeUsername } from './schemas';

export async function isUsernameAvailable(raw: string): Promise<boolean> {
  const username = normalizeUsername(raw);
  if (!USERNAME_REGEX.test(username) || isReservedUsername(username)) return false;
  const snap = await getDoc(doc(db, 'usernames', username));
  return !snap.exists();
}

/**
 * ينشئ ملف المستخدم وحجز اسم المستخدم في عملية ذرّية واحدة.
 * قواعد Firestore تتحقق من أن الوثيقتين تُكتبان معًا وأن الاسم غير محجوز.
 */
export async function createProfile(user: User, displayName: string, rawUsername: string): Promise<void> {
  const username = normalizeUsername(rawUsername);
  if (!USERNAME_REGEX.test(username) || isReservedUsername(username)) throw new AppError('username-invalid');

  const batch = writeBatch(db);
  batch.set(doc(db, 'usernames', username), { uid: user.uid, createdAt: serverTimestamp() });
  batch.set(doc(db, 'users', user.uid), {
    uid: user.uid,
    displayName: displayName.trim(),
    username,
    photoURL: user.photoURL && user.photoURL.startsWith('https://') ? user.photoURL : null,
    bio: '',
    joinedAt: serverTimestamp(),
    postsCount: 0,
    reactionsReceived: 0,
    followersCount: 0,
    followingCount: 0,
    privacy: DEFAULT_PRIVACY,
  });

  try {
    await batch.commit();
  } catch (err) {
    // فشل الإنشاء: غالبًا لأن الاسم محجوز بين التحقق والحجز
    const taken = await getDoc(doc(db, 'usernames', username)).then((s) => s.exists()).catch(() => false);
    if (taken) throw new AppError('username-taken');
    throw err;
  }
}

export interface SignupParams {
  email: string;
  password: string;
  displayName: string;
  username: string;
}

export async function registerWithEmail(p: SignupParams): Promise<void> {
  const flow = useAuthFlow.getState();
  flow.setBusy(true);
  try {
    if (!(await isUsernameAvailable(p.username))) throw new AppError('username-taken');
    const cred = await createUserWithEmailAndPassword(auth, p.email.trim(), p.password);
    try {
      await createProfile(cred.user, p.displayName, p.username);
    } catch (err) {
      // لا نترك حساب Auth بلا ملف؛ نحذفه ليتمكن المستخدم من إعادة المحاولة
      await cred.user.delete().catch(() => undefined);
      throw err;
    }
    await updateProfile(cred.user, { displayName: p.displayName.trim() }).catch(() => undefined);
    await sendEmailVerification(cred.user).catch(() => undefined);
  } finally {
    flow.setBusy(false);
  }
}

export async function loginWithEmail(email: string, password: string): Promise<void> {
  await signInWithEmailAndPassword(auth, email.trim(), password);
}

export async function loginWithGoogle(): Promise<void> {
  await signInWithPopup(auth, new GoogleAuthProvider());
}

export async function sendReset(email: string): Promise<void> {
  try {
    await sendPasswordResetEmail(auth, email.trim());
  } catch (err) {
    // لا نكشف إن كان البريد مسجلًا أم لا
    const code = (err as { code?: string }).code;
    if (code === 'auth/user-not-found' || code === 'auth/invalid-email') return;
    throw err;
  }
}

export async function logout(): Promise<void> {
  await signOut(auth);
}

export async function resendVerification(): Promise<void> {
  if (!auth.currentUser) throw new AppError('unauthenticated');
  await sendEmailVerification(auth.currentUser);
}

export async function reloadUser(): Promise<boolean> {
  if (!auth.currentUser) return false;
  await auth.currentUser.reload();
  return auth.currentUser.emailVerified;
}

export function usesPassword(user: User): boolean {
  return user.providerData.some((p) => p.providerId === 'password');
}

/** إعادة المصادقة قبل الإجراءات الحساسة (تغيير كلمة المرور، حذف الحساب). */
export async function reauthenticate(user: User, password?: string): Promise<void> {
  if (usesPassword(user)) {
    if (!user.email || !password) throw new AppError('auth/missing-password');
    await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email, password));
    return;
  }
  await reauthenticateWithPopup(user, new GoogleAuthProvider());
}

export async function changePassword(user: User, currentPassword: string, newPassword: string): Promise<void> {
  await reauthenticate(user, currentPassword);
  await updatePassword(user, newPassword);
}

/** حذف الحساب: إعادة مصادقة ثم دالة خادمية موثوقة تحذف البيانات المرتبطة وحساب Auth. */
export async function deleteAccount(user: User, password?: string): Promise<void> {
  await reauthenticate(user, password);
  await user.getIdToken(true);
  await httpsCallable(functions, 'deleteAccount')();
  await signOut(auth).catch(() => undefined);
}
