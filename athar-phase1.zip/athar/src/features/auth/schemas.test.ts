import { describe, expect, it } from 'vitest';
import {
  USERNAME_REGEX,
  changePasswordSchema,
  isReservedUsername,
  normalizeUsername,
  signupSchema,
  usernameSchema,
} from './schemas';

describe('username', () => {
  it('normalizes case, spaces and a leading @', () => {
    expect(normalizeUsername('  @Ahmad_01 ')).toBe('ahmad_01');
  });

  it.each(['abc', 'a_b', 'ahmad_2026', 'z'.padEnd(20, 'x')])('accepts %s', (u) => {
    expect(USERNAME_REGEX.test(u)).toBe(true);
  });

  it.each(['ab', '1abc', '_abc', 'has space', 'ملم', 'a'.padEnd(21, 'x'), 'bad-dash', 'UPPER'])('rejects %s', (u) => {
    expect(USERNAME_REGEX.test(u)).toBe(false);
  });

  it('rejects reserved names', () => {
    expect(isReservedUsername('Admin')).toBe(true);
    expect(usernameSchema.safeParse('admin').success).toBe(false);
    expect(usernameSchema.safeParse('Hamza_77').success).toBe(true);
  });
});

describe('signupSchema', () => {
  const valid = {
    displayName: 'أحمد',
    username: 'ahmad_1',
    email: 'a@example.com',
    password: 'abc12345',
    confirmPassword: 'abc12345',
  };

  it('accepts valid input and normalizes the username', () => {
    const r = signupSchema.safeParse({ ...valid, username: '@Ahmad_1' });
    expect(r.success).toBe(true);
    if (r.success) expect(r.data.username).toBe('ahmad_1');
  });

  it('rejects mismatching passwords', () => {
    const r = signupSchema.safeParse({ ...valid, confirmPassword: 'different1' });
    expect(r.success).toBe(false);
  });

  it('rejects short or weak passwords', () => {
    expect(signupSchema.safeParse({ ...valid, password: 'a1', confirmPassword: 'a1' }).success).toBe(false);
    expect(signupSchema.safeParse({ ...valid, password: 'abcdefgh', confirmPassword: 'abcdefgh' }).success).toBe(false);
    expect(signupSchema.safeParse({ ...valid, password: '12345678', confirmPassword: '12345678' }).success).toBe(false);
  });

  it('rejects bad email and short display name', () => {
    expect(signupSchema.safeParse({ ...valid, email: 'nope' }).success).toBe(false);
    expect(signupSchema.safeParse({ ...valid, displayName: 'أ' }).success).toBe(false);
  });
});

describe('changePasswordSchema', () => {
  it('requires current password and a strong new one', () => {
    expect(changePasswordSchema.safeParse({ currentPassword: '', newPassword: 'abc12345' }).success).toBe(false);
    expect(changePasswordSchema.safeParse({ currentPassword: 'x', newPassword: 'abc12345' }).success).toBe(true);
  });
});
