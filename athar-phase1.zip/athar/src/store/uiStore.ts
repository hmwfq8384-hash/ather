import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { applyDocumentLanguage, availableLanguages, type Lang } from '@/i18n';
import i18n from '@/i18n';

export type ThemeName = 'emerald' | 'mushaf' | 'night';
export type ThemePref = 'system' | ThemeName;
export type FontSize = 'sm' | 'md' | 'lg' | 'xl';
export type MotionPref = 'system' | 'reduce' | 'full';

export const THEME_COLORS: Record<ThemeName, string> = {
  emerald: '#081c16',
  mushaf: '#faf5e8',
  night: '#080c1e',
};

interface UiState {
  theme: ThemePref;
  fontSize: FontSize;
  motion: MotionPref;
  lang: Lang;
  setTheme: (t: ThemePref) => void;
  setFontSize: (f: FontSize) => void;
  setMotion: (m: MotionPref) => void;
  setLang: (l: Lang) => void;
}

export const useUiStore = create<UiState>()(
  persist(
    (set) => ({
      theme: 'system',
      fontSize: 'md',
      motion: 'system',
      lang: 'ar',
      setTheme: (theme) => set({ theme }),
      setFontSize: (fontSize) => set({ fontSize }),
      setMotion: (motion) => set({ motion }),
      setLang: (lang) => set({ lang }),
    }),
    {
      name: 'athar-ui',
      version: 1,
      partialize: (s) => ({ theme: s.theme, fontSize: s.fontSize, motion: s.motion, lang: s.lang }),
    },
  ),
);

/** الوضع التلقائي: الداكن → زمردي، الفاتح → نور المصحف. */
export function resolveTheme(pref: ThemePref, systemDark: boolean): ThemeName {
  if (pref !== 'system') return pref;
  return systemDark ? 'emerald' : 'mushaf';
}

export function resolveMotion(pref: MotionPref, systemReduce: boolean): 'reduce' | 'full' {
  if (pref === 'system') return systemReduce ? 'reduce' : 'full';
  return pref;
}

export interface UiSnapshot {
  theme: ThemePref;
  fontSize: FontSize;
  motion: MotionPref;
  lang: Lang;
}

/** يطبّق التفضيلات على عنصر html (دالة نقية قابلة للاختبار). */
export function applyUi(
  s: UiSnapshot,
  env: { systemDark: boolean; systemReduceMotion: boolean },
  doc: Document = document,
): void {
  const root = doc.documentElement;
  const theme = resolveTheme(s.theme, env.systemDark);
  root.setAttribute('data-theme', theme);
  root.setAttribute('data-font', s.fontSize);
  root.setAttribute('data-motion', resolveMotion(s.motion, env.systemReduceMotion));
  applyDocumentLanguage(s.lang, doc);
  doc.querySelector('meta[name="theme-color"]')?.setAttribute('content', THEME_COLORS[theme]);
}

/** يُستدعى مرة واحدة عند الإقلاع: يطبّق التفضيلات ويراقب تغيّرها وتغيّر إعدادات الجهاز. */
export function initUiEffects(): () => void {
  const dark = window.matchMedia('(prefers-color-scheme: dark)');
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');

  const run = () => {
    const s = useUiStore.getState();
    // لا نعرض لغة غير مكتملة حتى لو كانت محفوظة
    const lang: Lang = availableLanguages.includes(s.lang) ? s.lang : 'ar';
    applyUi(
      { theme: s.theme, fontSize: s.fontSize, motion: s.motion, lang },
      { systemDark: dark.matches, systemReduceMotion: reduce.matches },
    );
    if (i18n.language !== lang) void i18n.changeLanguage(lang);
  };

  run();
  const unsub = useUiStore.subscribe(run);
  dark.addEventListener('change', run);
  reduce.addEventListener('change', run);
  return () => {
    unsub();
    dark.removeEventListener('change', run);
    reduce.removeEventListener('change', run);
  };
}
