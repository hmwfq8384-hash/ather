import { beforeEach, describe, expect, it } from 'vitest';
import { applyUi, resolveMotion, resolveTheme, useUiStore } from './uiStore';

describe('theme resolution', () => {
  it('follows the device when set to system', () => {
    expect(resolveTheme('system', true)).toBe('emerald');
    expect(resolveTheme('system', false)).toBe('mushaf');
  });

  it('uses the explicit choice regardless of the device', () => {
    expect(resolveTheme('night', false)).toBe('night');
    expect(resolveTheme('mushaf', true)).toBe('mushaf');
    expect(resolveTheme('emerald', false)).toBe('emerald');
  });

  it('respects the device reduced-motion setting unless overridden', () => {
    expect(resolveMotion('system', true)).toBe('reduce');
    expect(resolveMotion('system', false)).toBe('full');
    expect(resolveMotion('full', true)).toBe('full');
    expect(resolveMotion('reduce', false)).toBe('reduce');
  });
});

describe('applyUi', () => {
  it('writes theme, font, motion and direction to <html>', () => {
    document.head.innerHTML = '<meta name="theme-color" content="#000">';
    applyUi(
      { theme: 'mushaf', fontSize: 'lg', motion: 'reduce', lang: 'ar' },
      { systemDark: true, systemReduceMotion: false },
    );
    const root = document.documentElement;
    expect(root.getAttribute('data-theme')).toBe('mushaf');
    expect(root.getAttribute('data-font')).toBe('lg');
    expect(root.getAttribute('data-motion')).toBe('reduce');
    expect(root.dir).toBe('rtl');
    expect(document.querySelector('meta[name="theme-color"]')?.getAttribute('content')).toBe('#faf5e8');
  });
});

describe('persistence', () => {
  beforeEach(() => {
    localStorage.clear();
    useUiStore.setState({ theme: 'system', fontSize: 'md', motion: 'system', lang: 'ar' });
  });

  it('stores the chosen theme and restores it after a "reopen"', async () => {
    useUiStore.getState().setTheme('mushaf');
    useUiStore.getState().setFontSize('xl');

    const raw = localStorage.getItem('athar-ui');
    expect(raw).toBeTruthy();
    expect(JSON.parse(raw as string).state.theme).toBe('mushaf');

    // محاكاة إغلاق التطبيق: تفريغ الحالة ثم إعادة التحميل من التخزين
    useUiStore.setState({ theme: 'system', fontSize: 'md' });
    await useUiStore.persist.rehydrate();

    expect(useUiStore.getState().theme).toBe('mushaf');
    expect(useUiStore.getState().fontSize).toBe('xl');
  });
});
