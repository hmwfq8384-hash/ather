import { HeartHandshake } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { EmptyState } from '@/components/ui/EmptyState';

/** تُستبدل هذه الحالة الفارغة بتغذية المنشورات في المرحلة الثانية. */
export default function HomePage() {
  const { t } = useTranslation();
  return (
    <section aria-labelledby="home-title">
      <h1 id="home-title" className="sr-only">
        {t('nav.home')}
      </h1>
      <div className="card">
        <EmptyState icon={HeartHandshake} title={t('pages.homeEmptyTitle')} body={t('pages.homeEmptyBody')} />
      </div>
    </section>
  );
}
