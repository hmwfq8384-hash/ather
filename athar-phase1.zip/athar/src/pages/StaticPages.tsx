import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Logo } from '@/components/Logo';

function Shell({ title, children }: { title: string; children: React.ReactNode }) {
  const { t } = useTranslation();
  return (
    <main className="mx-auto min-h-dvh max-w-2xl px-4 py-8 pt-safe">
      <Link to="/" className="mb-4 inline-flex items-center gap-1 text-sm text-muted hover:text-fg">
        <ArrowRight className="h-4 w-4" aria-hidden />
        {t('common.back')}
      </Link>
      <article className="card p-6">
        <header className="mb-4 flex items-center gap-3">
          <Logo size={40} />
          <h1 className="text-2xl font-bold">{title}</h1>
        </header>
        {children}
      </article>
    </main>
  );
}

function List({ items }: { items: string[] }) {
  return (
    <ul className="list-disc space-y-3 ps-5 leading-8">
      {items.map((x) => (
        <li key={x}>{x}</li>
      ))}
    </ul>
  );
}

export function AboutPage() {
  const { t } = useTranslation();
  return (
    <Shell title={t('pages.aboutTitle')}>
      <p className="leading-8">{t('pages.aboutBody')}</p>
      <p className="mt-4 text-accent">{t('app.tagline')}</p>
    </Shell>
  );
}

export function PrivacyPage() {
  const { t } = useTranslation();
  return (
    <Shell title={t('pages.privacyTitle')}>
      <List items={t('legal.privacy', { returnObjects: true }) as unknown as string[]} />
    </Shell>
  );
}

export function TermsPage() {
  const { t } = useTranslation();
  return (
    <Shell title={t('pages.termsTitle')}>
      <List items={t('legal.terms', { returnObjects: true }) as unknown as string[]} />
    </Shell>
  );
}
