import { Link } from 'react-router-dom';
import { SearchX } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { EmptyState } from '@/components/ui/EmptyState';

export default function NotFoundPage() {
  const { t } = useTranslation();
  return (
    <div className="mx-auto flex min-h-dvh max-w-md items-center">
      <EmptyState
        icon={SearchX}
        title={t('pages.notFoundTitle')}
        body={t('pages.notFoundBody')}
        action={
          <Link to="/" className="font-semibold text-accent hover:underline">
            {t('pages.goHome')}
          </Link>
        }
      />
    </div>
  );
}
