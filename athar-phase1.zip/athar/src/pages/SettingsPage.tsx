import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/Button';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { useCurrentProfile } from '@/features/auth/AuthProvider';
import { logout, usesPassword } from '@/features/auth/authService';
import type { PrivacySettings } from '@/features/auth/types';
import { EditProfileModal } from '@/features/profile/EditProfileModal';
import { updatePrivacy } from '@/features/profile/profileService';
import { ChangePasswordModal } from '@/features/settings/ChangePasswordModal';
import { DeleteAccountDialog } from '@/features/settings/DeleteAccountDialog';
import { ChoiceGroup, Row, Section, SwitchRow } from '@/features/settings/SettingsParts';
import { availableLanguages } from '@/i18n';
import { appVersion } from '@/lib/env';
import { toArabicError } from '@/lib/errors';
import { toast } from '@/store/toastStore';
import { useUiStore, type FontSize, type MotionPref, type ThemePref } from '@/store/uiStore';

export default function SettingsPage() {
  const { t } = useTranslation();
  const { user, profile } = useCurrentProfile();
  const ui = useUiStore();
  const [editing, setEditing] = useState(false);
  const [changingPw, setChangingPw] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [savingPrivacy, setSavingPrivacy] = useState(false);

  const setPrivacy = async (patch: Partial<PrivacySettings>) => {
    setSavingPrivacy(true);
    try {
      await updatePrivacy(profile.uid, { ...profile.privacy, ...patch });
    } catch (err) {
      toast.error(toArabicError(err));
    } finally {
      setSavingPrivacy(false);
    }
  };

  const themeOptions: Array<{ value: ThemePref; label: string }> = [
    { value: 'system', label: t('settings.themeSystem') },
    { value: 'emerald', label: t('settings.themeEmerald') },
    { value: 'mushaf', label: t('settings.themeMushaf') },
    { value: 'night', label: t('settings.themeNight') },
  ];
  const fontOptions: Array<{ value: FontSize; label: string }> = [
    { value: 'sm', label: t('settings.fontSm') },
    { value: 'md', label: t('settings.fontMd') },
    { value: 'lg', label: t('settings.fontLg') },
    { value: 'xl', label: t('settings.fontXl') },
  ];
  const motionOptions: Array<{ value: MotionPref; label: string }> = [
    { value: 'system', label: t('settings.motionSystem') },
    { value: 'reduce', label: t('settings.motionReduce') },
    { value: 'full', label: t('settings.motionFull') },
  ];
  const englishReady = availableLanguages.includes('en');

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">{t('settings.title')}</h1>

      <Section title={t('settings.account')}>
        <Row>
          <span>{t('settings.editName')}</span>
          <Button size="sm" variant="outline" onClick={() => setEditing(true)}>
            {t('common.edit')}
          </Button>
        </Row>
        <Row>
          <div className="min-w-0">
            <div className="text-xs text-muted">{t('settings.email')}</div>
            <div dir="ltr" className="truncate text-start">
              {user.email}
            </div>
          </div>
          <span className={user.emailVerified ? 'text-sm text-success' : 'text-sm text-accent'}>
            {user.emailVerified ? t('settings.emailVerified') : t('settings.emailNotVerified')}
          </span>
        </Row>
        <Row>
          {usesPassword(user) ? (
            <>
              <span>{t('settings.changePassword')}</span>
              <Button size="sm" variant="outline" onClick={() => setChangingPw(true)}>
                {t('common.edit')}
              </Button>
            </>
          ) : (
            <span className="text-sm text-muted">{t('settings.googleManaged')}</span>
          )}
        </Row>
        <Row>
          <span>{t('auth.logout')}</span>
          <Button size="sm" variant="outline" onClick={() => setSigningOut(true)}>
            {t('auth.logout')}
          </Button>
        </Row>
        <Row>
          <div className="min-w-0">
            <div className="font-medium text-danger">{t('settings.deleteAccount')}</div>
            <div className="text-xs leading-6 text-muted">{t('settings.deleteWarning')}</div>
          </div>
          <Button size="sm" variant="danger" onClick={() => setDeleting(true)}>
            {t('common.delete')}
          </Button>
        </Row>
      </Section>

      <Section title={t('settings.appearance')}>
        <div className="px-4 pt-3 text-sm font-medium">{t('settings.theme')}</div>
        <ChoiceGroup label={t('settings.theme')} value={ui.theme} onChange={ui.setTheme} options={themeOptions} />
        <div className="px-4 pt-3 text-sm font-medium">{t('settings.fontSize')}</div>
        <ChoiceGroup label={t('settings.fontSize')} value={ui.fontSize} onChange={ui.setFontSize} options={fontOptions} />
        <div className="px-4 pt-3 text-sm font-medium">{t('settings.motion')}</div>
        <ChoiceGroup label={t('settings.motion')} value={ui.motion} onChange={ui.setMotion} options={motionOptions} />
      </Section>

      <Section title={t('settings.language')}>
        <ChoiceGroup
          label={t('settings.language')}
          value={ui.lang}
          onChange={ui.setLang}
          options={[
            { value: 'ar', label: t('settings.langAr') },
            { value: 'en', label: t('settings.langEn'), disabled: !englishReady },
          ]}
        />
        {!englishReady && <p className="px-4 pb-3 text-xs text-muted">{t('settings.langEnUnavailable')}</p>}
      </Section>

      <Section title={t('settings.privacy')}>
        <SwitchRow
          label={t('settings.privateAccount')}
          hint={t('settings.privateAccountHint')}
          checked={profile.privacy.isPrivate}
          onChange={(v) => void setPrivacy({ isPrivate: v })}
          disabled={savingPrivacy}
        />
        <SwitchRow
          label={t('settings.showHifz')}
          checked={profile.privacy.showHifz}
          onChange={(v) => void setPrivacy({ showHifz: v })}
          disabled={savingPrivacy}
        />
        <SwitchRow
          label={t('settings.showAchievements')}
          checked={profile.privacy.showAchievements}
          onChange={(v) => void setPrivacy({ showAchievements: v })}
          disabled={savingPrivacy}
        />
        <SwitchRow
          label={t('settings.showFollowLists')}
          checked={profile.privacy.showFollowLists}
          onChange={(v) => void setPrivacy({ showFollowLists: v })}
          disabled={savingPrivacy}
        />
        <SwitchRow
          label={t('settings.allowPartnerRequests')}
          checked={profile.privacy.allowPartnerRequests}
          onChange={(v) => void setPrivacy({ allowPartnerRequests: v })}
          disabled={savingPrivacy}
        />
      </Section>

      <Section title={t('settings.about')}>
        {[
          { to: '/about', label: t('settings.aboutApp') },
          { to: '/privacy', label: t('settings.privacyPolicy') },
          { to: '/terms', label: t('settings.terms') },
        ].map((l) => (
          <Link key={l.to} to={l.to} className="flex items-center justify-between px-4 py-3 hover:bg-surface2">
            {l.label}
            <ChevronLeft className="h-4 w-4 text-muted" aria-hidden />
          </Link>
        ))}
        <Row>
          <span>{t('settings.version')}</span>
          <span dir="ltr" className="text-sm text-muted">
            {appVersion}
          </span>
        </Row>
      </Section>

      <EditProfileModal key={`edit-${editing}`} open={editing} profile={profile} onClose={() => setEditing(false)} />
      {usesPassword(user) && <ChangePasswordModal open={changingPw} user={user} onClose={() => setChangingPw(false)} />}
      <DeleteAccountDialog open={deleting} user={user} onClose={() => setDeleting(false)} />
      <ConfirmDialog
        open={signingOut}
        title={t('auth.logout')}
        description={t('settings.signOutConfirm')}
        confirmLabel={t('auth.logout')}
        onConfirm={async () => {
          await logout();
        }}
        onClose={() => setSigningOut(false)}
      />
    </div>
  );
}
