import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { AuthShell } from '@/features/auth/AuthShell';
import { GoogleButton } from '@/features/auth/GoogleButton';
import { loginWithEmail } from '@/features/auth/authService';
import { loginSchema, msg, type LoginInput } from '@/features/auth/schemas';
import { toArabicError } from '@/lib/errors';
import { toast } from '@/store/toastStore';

export default function LoginPage() {
  const { t } = useTranslation();
  const [submitting, setSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginInput>({ resolver: zodResolver(loginSchema) });

  const onSubmit = handleSubmit(async (values) => {
    setSubmitting(true);
    try {
      await loginWithEmail(values.email, values.password);
      // التحويل يتم تلقائيًا عند تغيّر حالة المصادقة
    } catch (err) {
      toast.error(toArabicError(err));
      setSubmitting(false);
    }
  });

  return (
    <AuthShell title={t('auth.loginTitle')} subtitle={t('auth.loginSubtitle')}>
      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        <Input
          label={t('auth.email')}
          type="email"
          dir="ltr"
          autoComplete="email"
          inputMode="email"
          className="text-left"
          error={msg(errors.email?.message)}
          {...register('email')}
        />
        <Input
          label={t('auth.password')}
          type="password"
          dir="ltr"
          autoComplete="current-password"
          className="text-left"
          error={msg(errors.password?.message)}
          {...register('password')}
        />
        <div className="text-end">
          <Link to="/forgot-password" className="text-sm text-accent hover:underline">
            {t('auth.forgotPassword')}
          </Link>
        </div>
        <Button type="submit" block loading={submitting}>
          {t('auth.loginTitle')}
        </Button>
      </form>
      <GoogleButton />
      <p className="mt-5 text-center text-sm text-muted">
        {t('auth.noAccount')}{' '}
        <Link to="/signup" className="font-semibold text-accent hover:underline">
          {t('welcome.createAccount')}
        </Link>
      </p>
    </AuthShell>
  );
}
