import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { AuthShell } from '@/features/auth/AuthShell';
import { GoogleButton } from '@/features/auth/GoogleButton';
import { UsernameField } from '@/features/auth/UsernameField';
import { registerWithEmail } from '@/features/auth/authService';
import { msg, signupSchema, type SignupInput } from '@/features/auth/schemas';
import { toArabicError } from '@/lib/errors';
import { toast } from '@/store/toastStore';

export default function SignupPage() {
  const { t } = useTranslation();
  const [submitting, setSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<SignupInput>({ resolver: zodResolver(signupSchema), mode: 'onBlur' });

  const onSubmit = handleSubmit(async (values) => {
    setSubmitting(true);
    try {
      await registerWithEmail({
        email: values.email,
        password: values.password,
        displayName: values.displayName,
        username: values.username,
      });
    } catch (err) {
      toast.error(toArabicError(err));
      setSubmitting(false);
    }
  });

  return (
    <AuthShell title={t('auth.signupTitle')} subtitle={t('auth.signupSubtitle')}>
      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        <Input
          label={t('auth.displayName')}
          autoComplete="name"
          maxLength={40}
          error={msg(errors.displayName?.message)}
          {...register('displayName')}
        />
        <UsernameField
          register={register('username')}
          value={watch('username') ?? ''}
          error={msg(errors.username?.message)}
        />
        <Input
          label={t('auth.email')}
          type="email"
          dir="ltr"
          autoComplete="email"
          inputMode="email"
          className="text-left"
          error={msg(errors.email?.message)}
          {...register('email')}
        />
        <Input
          label={t('auth.password')}
          type="password"
          dir="ltr"
          autoComplete="new-password"
          className="text-left"
          hint={t('auth.passwordHint')}
          error={msg(errors.password?.message)}
          {...register('password')}
        />
        <Input
          label={t('auth.confirmPassword')}
          type="password"
          dir="ltr"
          autoComplete="new-password"
          className="text-left"
          error={msg(errors.confirmPassword?.message)}
          {...register('confirmPassword')}
        />
        <Button type="submit" block loading={submitting}>
          {t('welcome.createAccount')}
        </Button>
      </form>
      <GoogleButton />
      <p className="mt-5 text-center text-sm text-muted">
        {t('auth.haveAccount')}{' '}
        <Link to="/login" className="font-semibold text-accent hover:underline">
          {t('welcome.login')}
        </Link>
      </p>
    </AuthShell>
  );
}
