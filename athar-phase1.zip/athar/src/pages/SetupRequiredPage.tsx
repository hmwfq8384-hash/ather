import { Settings2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { EmptyState } from '@/components/ui/EmptyState';

export default function SetupRequiredPage() {
  const { t } = useTranslation();
  return (
    <main className="mx-auto flex min-h-dvh max-w-md items-center">
      <EmptyState
        icon={Settings2}
        title={t('setup.title')}
        body={`${t('setup.body')} ${t('setup.docs')}`}
      />
    </main>
  );
}
