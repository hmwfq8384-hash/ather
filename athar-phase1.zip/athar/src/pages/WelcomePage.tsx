import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Logo } from '@/components/Logo';

export default function WelcomePage() {
  const { t } = useTranslation();
  return (
    <main className="relative mx-auto flex min-h-dvh w-full max-w-md flex-col items-center justify-center gap-8 overflow-hidden px-6 py-10 text-center pt-safe pb-safe">
      {/* نمط هندسي هادئ في الخلفية */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            'radial-gradient(circle at 50% 50%, rgb(var(--c-accent)) 1px, transparent 1.5px), radial-gradient(circle at 0 0, rgb(var(--c-accent)) 1px, transparent 1.5px)',
          backgroundSize: '28px 28px, 28px 28px',
          backgroundPosition: '0 0, 14px 14px',
        }}
      />
      <div className="relative flex flex-col items-center gap-4">
        <Logo size={112} />
        <h1 className="text-5xl font-bold text-accent">{t('app.name')}</h1>
        <p className="text-lg leading-8">{t('app.tagline')}</p>
        <p className="font-quran text-lg text-muted">{t('welcome.quote')}</p>
      </div>
      <div className="relative flex w-full flex-col gap-3">
        <Link
          to="/signup"
          className="inline-flex h-12 items-center justify-center rounded-xl bg-accent px-6 font-semibold text-accentfg hover:opacity-90"
        >
          {t('welcome.createAccount')}
        </Link>
        <Link
          to="/login"
          className="inline-flex h-12 items-center justify-center rounded-xl border border-border px-6 font-semibold hover:bg-surface2"
        >
          {t('welcome.login')}
        </Link>
      </div>
    </main>
  );
}
