import { useState } from 'react';
import { Link, Navigate, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { FileText, Lock, Settings, UserX } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Avatar } from '@/components/ui/Avatar';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { ProfileSkeleton } from '@/components/ui/Skeleton';
import { useAuth, useCurrentProfile } from '@/features/auth/AuthProvider';
import type { UserProfile } from '@/features/auth/types';
import { EditProfileModal } from '@/features/profile/EditProfileModal';
import { getProfileByUsername } from '@/features/profile/profileService';
import { formatDate, formatNumber } from '@/lib/utils';
import { toArabicError } from '@/lib/errors';

export function MeRedirect() {
  const { profile } = useAuth();
  if (!profile) return null;
  return <Navigate to={`/u/${profile.username}`} replace />;
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div className="flex-1 text-center">
      <div className="text-xl font-bold">{formatNumber(value)}</div>
      <div className="text-xs text-muted">{label}</div>
    </div>
  );
}

export default function ProfilePage() {
  const { t } = useTranslation();
  const { username = '' } = useParams();
  const { profile: me } = useCurrentProfile();
  const [editing, setEditing] = useState(false);
  const isMe = me.username === username.toLowerCase();

  const query = useQuery<UserProfile | null>({
    queryKey: ['profile', username.toLowerCase()],
    queryFn: () => getProfileByUsername(username),
    enabled: !isMe,
    staleTime: 60_000,
  });

  const profile: UserProfile | null | undefined = isMe ? me : query.data;

  if (!isMe && query.isLoading) return <ProfileSkeleton />;
  if (!isMe && query.isError) {
    return (
      <div className="card">
        <EmptyState
          icon={UserX}
          title={toArabicError(query.error)}
          action={<Button onClick={() => void query.refetch()}>{t('common.retry')}</Button>}
        />
      </div>
    );
  }
  if (!profile) {
    return (
      <div className="card">
        <EmptyState icon={UserX} title={t('profile.notFound')} body={t('profile.notFoundBody')} />
      </div>
    );
  }

  const hiddenPrivate = profile.privacy.isPrivate && !isMe;

  return (
    <div className="space-y-4">
      <header className="card p-5">
        <div className="flex items-start gap-4">
          <Avatar src={profile.photoURL} name={profile.displayName} size={80} />
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-xl font-bold">{profile.displayName}</h1>
            <p dir="ltr" className="truncate text-start text-sm text-muted">
              @{profile.username}
            </p>
            {profile.joinedAt && (
              <p className="mt-1 text-xs text-muted">
                {t('profile.joined', { date: formatDate(profile.joinedAt) })}
              </p>
            )}
          </div>
          {isMe && (
            <Link
              to="/settings"
              aria-label={t('nav.settings')}
              className="rounded-lg p-2 text-muted hover:bg-surface2 hover:text-fg"
            >
              <Settings className="h-5 w-5" aria-hidden />
            </Link>
          )}
        </div>

        {profile.bio && <p className="mt-4 whitespace-pre-line text-sm leading-7">{profile.bio}</p>}

        {!hiddenPrivate && (
          <div className="mt-5 flex divide-x divide-border rtl:divide-x-reverse border-t border-border pt-4">
            <Stat value={profile.postsCount} label={t('profile.posts')} />
            <Stat value={profile.reactionsReceived} label={t('profile.reactions')} />
            <Stat value={profile.followersCount} label={t('profile.followers')} />
            <Stat value={profile.followingCount} label={t('profile.following')} />
          </div>
        )}

        {isMe && (
          <Button variant="outline" block className="mt-4" onClick={() => setEditing(true)}>
            {t('profile.editProfile')}
          </Button>
        )}
      </header>

      <section className="card" aria-label={t('profile.posts')}>
        {hiddenPrivate ? (
          <EmptyState icon={Lock} title={t('profile.private')} body={t('profile.privateBody')} />
        ) : (
          <EmptyState
            icon={FileText}
            title={t('profile.emptyPostsTitle')}
            body={isMe ? t('profile.emptyPostsOwn') : t('profile.emptyPostsOther')}
          />
        )}
      </section>

      {isMe && <EditProfileModal key={String(editing)} open={editing} profile={me} onClose={() => setEditing(false)} />}
    </div>
  );
}
