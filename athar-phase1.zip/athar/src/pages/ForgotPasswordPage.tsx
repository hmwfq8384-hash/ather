import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { AuthShell } from '@/features/auth/AuthShell';
import { sendReset } from '@/features/auth/authService';
import { msg, resetSchema } from '@/features/auth/schemas';
import { toArabicError } from '@/lib/errors';
import { toast } from '@/store/toastStore';
import type { z } from 'zod';

type ResetInput = z.input<typeof resetSchema>;

export default function ForgotPasswordPage() {
  const { t } = useTranslation();
  const [sent, setSent] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ResetInput>({ resolver: zodResolver(resetSchema) });

  const onSubmit = handleSubmit(async ({ email }) => {
    setSubmitting(true);
    try {
      await sendReset(email);
      setSent(true);
    } catch (err) {
      toast.error(toArabicError(err));
    } finally {
      setSubmitting(false);
    }
  });

  return (
    <AuthShell title={t('auth.resetTitle')} subtitle={t('auth.resetSubtitle')} backTo="/login">
      {sent ? (
        <div className="space-y-4 text-center">
          <p role="status" className="text-sm leading-7">
            {t('auth.resetSent')}
          </p>
          <Link to="/login" className="font-semibold text-accent hover:underline">
            {t('auth.backToLogin')}
          </Link>
        </div>
      ) : (
        <form onSubmit={onSubmit} className="space-y-4" noValidate>
          <Input
            label={t('auth.email')}
            type="email"
            dir="ltr"
            autoComplete="email"
            inputMode="email"
            className="text-left"
            error={msg(errors.email?.message)}
            {...register('email')}
          />
          <Button type="submit" block loading={submitting}>
            {t('auth.sendReset')}
          </Button>
        </form>
      )}
    </AuthShell>
  );
}
