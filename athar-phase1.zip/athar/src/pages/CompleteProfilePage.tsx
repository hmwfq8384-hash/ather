import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { AuthShell } from '@/features/auth/AuthShell';
import { UsernameField } from '@/features/auth/UsernameField';
import { useAuth } from '@/features/auth/AuthProvider';
import { createProfile, logout } from '@/features/auth/authService';
import { completeProfileSchema, msg, type CompleteProfileInput } from '@/features/auth/schemas';
import { toArabicError } from '@/lib/errors';
import { toast } from '@/store/toastStore';

/** تظهر لمن سجّل الدخول (مثل Google) ولا يملك ملفًا شخصيًا بعد. */
export default function CompleteProfilePage() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [submitting, setSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<CompleteProfileInput>({
    resolver: zodResolver(completeProfileSchema),
    defaultValues: { displayName: user?.displayName ?? '', username: '' },
  });

  const onSubmit = handleSubmit(async (values) => {
    if (!user) return;
    setSubmitting(true);
    try {
      await createProfile(user, values.displayName, values.username);
    } catch (err) {
      toast.error(toArabicError(err));
      setSubmitting(false);
    }
  });

  return (
    <AuthShell title={t('auth.completeTitle')} subtitle={t('auth.completeSubtitle')}>
      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        <Input
          label={t('auth.displayName')}
          maxLength={40}
          error={msg(errors.displayName?.message)}
          {...register('displayName')}
        />
        <UsernameField
          register={register('username')}
          value={watch('username') ?? ''}
          error={msg(errors.username?.message)}
        />
        <Button type="submit" block loading={submitting}>
          {t('auth.completeAction')}
        </Button>
        <Button variant="ghost" block onClick={() => void logout()} disabled={submitting}>
          {t('auth.logout')}
        </Button>
      </form>
    </AuthShell>
  );
}
