import type { ReactNode } from 'react';
import type { LucideIcon } from 'lucide-react';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  body?: string;
  action?: ReactNode;
}

export function EmptyState({ icon: Icon, title, body, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center gap-3 px-6 py-12 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-surface2 text-accent">
        <Icon className="h-8 w-8" aria-hidden />
      </div>
      <h2 className="text-lg font-bold">{title}</h2>
      {body && <p className="max-w-sm text-sm leading-7 text-muted">{body}</p>}
      {action}
    </div>
  );
}
