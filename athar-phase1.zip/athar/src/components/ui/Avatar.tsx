import { useState } from 'react';
import { cn } from '@/lib/utils';

interface AvatarProps {
  src: string | null | undefined;
  name: string;
  size?: number;
  className?: string;
}

export function Avatar({ src, name, size = 40, className }: AvatarProps) {
  const [failed, setFailed] = useState(false);
  const initial = Array.from(name.trim())[0] ?? '؟';
  const style = { width: size, height: size, fontSize: size * 0.42 };

  if (src && !failed) {
    return (
      <img
        src={src}
        alt={name}
        width={size}
        height={size}
        loading="lazy"
        decoding="async"
        referrerPolicy="no-referrer"
        onError={() => setFailed(true)}
        style={style}
        className={cn('shrink-0 rounded-full border border-border object-cover', className)}
      />
    );
  }
  return (
    <span
      role="img"
      aria-label={name}
      style={style}
      className={cn(
        'inline-flex shrink-0 items-center justify-center rounded-full border border-border bg-surface2 font-bold text-accent',
        className,
      )}
    >
      {initial}
    </span>
  );
}
