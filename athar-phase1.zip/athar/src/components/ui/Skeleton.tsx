import { cn } from '@/lib/utils';

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('skeleton', className)} aria-hidden />;
}

export function ProfileSkeleton() {
  return (
    <div className="space-y-4" role="status" aria-busy="true">
      <div className="card flex items-center gap-4 p-5">
        <Skeleton className="h-20 w-20 rounded-full" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-5 w-1/2" />
          <Skeleton className="h-4 w-1/3" />
        </div>
      </div>
      <Skeleton className="h-24 w-full" />
    </div>
  );
}

export function FullScreenLoader() {
  return (
    <div className="flex min-h-dvh items-center justify-center" role="status" aria-busy="true">
      <div className="skeleton h-16 w-16 rounded-full" />
    </div>
  );
}
