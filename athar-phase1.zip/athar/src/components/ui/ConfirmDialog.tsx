import { useState, type ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from './Button';
import { Modal } from './Modal';

interface ConfirmDialogProps {
  open: boolean;
  title: string;
  description?: ReactNode;
  confirmLabel: string;
  danger?: boolean;
  onConfirm: () => Promise<void> | void;
  onClose: () => void;
  children?: ReactNode;
}

/** نافذة تأكيد للإجراءات الحساسة. تبقى مفتوحة عند الفشل ليتمكن المستخدم من المحاولة مجددًا. */
export function ConfirmDialog({ open, title, description, confirmLabel, danger, onConfirm, onClose, children }: ConfirmDialogProps) {
  const { t } = useTranslation();
  const [busy, setBusy] = useState(false);

  const run = async () => {
    setBusy(true);
    try {
      await onConfirm();
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} title={title} onClose={onClose} locked={busy}>
      {description && <p className="mb-4 text-sm leading-7 text-muted">{description}</p>}
      {children}
      <div className="mt-5 flex gap-3">
        <Button variant={danger ? 'danger' : 'primary'} onClick={run} loading={busy} className="flex-1">
          {confirmLabel}
        </Button>
        <Button variant="outline" onClick={onClose} disabled={busy} className="flex-1">
          {t('common.cancel')}
        </Button>
      </div>
    </Modal>
  );
}
