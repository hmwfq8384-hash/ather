import { Suspense } from 'react';
import { Outlet } from 'react-router-dom';
import { ProfileSkeleton } from '@/components/ui/Skeleton';
import { BottomNav } from './BottomNav';
import { OfflineBanner, VerifyEmailBanner } from './Banners';
import { Sidebar } from './Sidebar';

export function AppLayout() {
  return (
    <div className="mx-auto flex min-h-dvh max-w-6xl">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <OfflineBanner />
        <VerifyEmailBanner />
        <main className="mx-auto w-full max-w-2xl flex-1 px-4 pb-28 pt-[max(1.5rem,env(safe-area-inset-top))] lg:pb-10">
          <Suspense fallback={<ProfileSkeleton />}>
            <Outlet />
          </Suspense>
        </main>
      </div>
      <BottomNav />
    </div>
  );
}
