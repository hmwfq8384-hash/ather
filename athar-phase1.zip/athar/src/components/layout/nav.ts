import { Home, Settings, User, type LucideIcon } from 'lucide-react';

export interface NavItem {
  to: string;
  labelKey: string;
  icon: LucideIcon;
  end?: boolean;
}

/**
 * عناصر التنقل المنفَّذة فعليًا. تُضاف بقية الأقسام (سباق الحفاظ، إضافة منشور، عباداتي)
 * في مراحلها بعد اكتمال صفحاتها، حتى لا توجد أزرار بلا وجهة.
 */
export const NAV_ITEMS: NavItem[] = [
  { to: '/', labelKey: 'nav.home', icon: Home, end: true },
  { to: '/me', labelKey: 'nav.account', icon: User },
];

export const SIDEBAR_EXTRA: NavItem[] = [{ to: '/settings', labelKey: 'nav.settings', icon: Settings }];
