import { useEffect, useState } from 'react';
import { MailWarning, WifiOff } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/Button';
import { useAuth } from '@/features/auth/AuthProvider';
import { reloadUser, resendVerification, usesPassword } from '@/features/auth/authService';
import { toArabicError } from '@/lib/errors';
import { toast } from '@/store/toastStore';

export function OfflineBanner() {
  const { t } = useTranslation();
  const [online, setOnline] = useState(() => navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);
  if (online) return null;
  return (
    <div role="status" className="flex items-center gap-2 bg-danger/15 px-4 py-2 text-sm text-danger">
      <WifiOff className="h-4 w-4 shrink-0" aria-hidden />
      {t('offline.banner')}
    </div>
  );
}

/** يظهر لمن لم يفعّل بريده (حسابات البريد وكلمة المرور فقط). */
export function VerifyEmailBanner() {
  const { t } = useTranslation();
  const { user, bumpUser } = useAuth();
  const [busy, setBusy] = useState<'send' | 'check' | null>(null);

  if (!user || user.emailVerified || !usesPassword(user)) return null;

  const resend = async () => {
    setBusy('send');
    try {
      await resendVerification();
      toast.success(t('auth.verifySent'));
    } catch (err) {
      toast.error(toArabicError(err));
    } finally {
      setBusy(null);
    }
  };

  const check = async () => {
    setBusy('check');
    try {
      const verified = await reloadUser();
      bumpUser();
      if (verified) toast.success(t('auth.verifyDone'));
      else toast.info(t('auth.verifyStill'));
    } catch (err) {
      toast.error(toArabicError(err));
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-3 border-b border-border bg-accent/10 px-4 py-3 text-sm">
      <MailWarning className="h-5 w-5 shrink-0 text-accent" aria-hidden />
      <div className="min-w-0 flex-1">
        <p className="font-semibold">{t('auth.verifyTitle')}</p>
        <p className="text-muted">{t('auth.verifyBody')}</p>
      </div>
      <div className="flex gap-2">
        <Button size="sm" variant="outline" onClick={resend} loading={busy === 'send'}>
          {t('auth.verifyResend')}
        </Button>
        <Button size="sm" onClick={check} loading={busy === 'check'}>
          {t('auth.verifyRefresh')}
        </Button>
      </div>
    </div>
  );
}
