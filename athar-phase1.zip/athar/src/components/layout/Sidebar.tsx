import { NavLink } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Logo } from '@/components/Logo';
import { Avatar } from '@/components/ui/Avatar';
import { useCurrentProfile } from '@/features/auth/AuthProvider';
import { cn } from '@/lib/utils';
import { NAV_ITEMS, SIDEBAR_EXTRA } from './nav';

export function Sidebar() {
  const { t } = useTranslation();
  const { profile } = useCurrentProfile();
  const items = [...NAV_ITEMS, ...SIDEBAR_EXTRA];

  return (
    <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col gap-6 border-e border-border bg-surface/60 p-4 lg:flex">
      <div className="flex items-center gap-3 px-2 pt-2">
        <Logo size={40} />
        <span className="text-2xl font-bold text-accent">{t('app.name')}</span>
      </div>
      <nav aria-label={t('nav.mainNav')} className="flex-1">
        <ul className="space-y-1">
          {items.map(({ to, labelKey, icon: Icon, end }) => (
            <li key={to}>
              <NavLink
                to={to}
                end={end}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-3 rounded-xl px-3 py-2.5 font-medium',
                    isActive ? 'bg-surface2 text-accent' : 'text-muted hover:bg-surface2 hover:text-fg',
                  )
                }
              >
                <Icon className="h-5 w-5" aria-hidden />
                {t(labelKey)}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
      <NavLink to="/me" className="flex items-center gap-3 rounded-xl p-2 hover:bg-surface2">
        <Avatar src={profile.photoURL} name={profile.displayName} size={40} />
        <span className="min-w-0">
          <span className="block truncate text-sm font-semibold">{profile.displayName}</span>
          <span dir="ltr" className="block truncate text-start text-xs text-muted">
            @{profile.username}
          </span>
        </span>
      </NavLink>
    </aside>
  );
}
