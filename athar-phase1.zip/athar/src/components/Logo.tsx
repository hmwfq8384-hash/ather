import { cn } from '@/lib/utils';

export function Logo({ size = 64, className }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 512 512"
      role="img"
      aria-label="أَثَر"
      className={cn('shrink-0', className)}
    >
      <circle cx="256" cy="256" r="220" fill="rgb(var(--c-surface))" stroke="rgb(var(--c-accent))" strokeWidth="14" />
      <circle cx="256" cy="256" r="176" fill="none" stroke="rgb(var(--c-accent))" strokeWidth="4" opacity=".5" />
      <text x="256" y="322" textAnchor="middle" fontFamily="Amiri, serif" fontSize="220" fill="rgb(var(--c-fg))">
        أ
      </text>
    </svg>
  );
}
